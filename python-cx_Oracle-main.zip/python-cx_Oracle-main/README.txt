An enhanced cx_Oracle release is now under the python-oracledb namespace.  See
https://oracle.github.io/python-oracledb/index.html for how to install and use
this updated driver.

For information about cx_Oracle itself, see
https://oracle.github.io/python-cx_Oracle/index.html

