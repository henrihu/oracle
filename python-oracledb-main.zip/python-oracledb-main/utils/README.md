This directory contains utility scripts for generating parameter files from
templates using the configuration stored in fields.cfg.

Generation is used instead of dynamic runtime equivalents in order to allow
static analyzers (such as those used in Visual Studio Code) to benefit.
