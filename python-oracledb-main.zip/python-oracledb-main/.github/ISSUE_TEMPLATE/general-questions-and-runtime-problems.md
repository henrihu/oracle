---
name: Questions and Runtime Problems
about: For general python-oracledb questions
title: ''
labels: question
assignees: ''

---

<!--

Please start a discussion at https://github.com/oracle/python-oracledb/discussions instead of creating an Issue.

Give as much background information as possible: versions, runnable code, all SQL to create tables etc.

-->
